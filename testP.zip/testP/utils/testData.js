module.exports = {
    validUser: {
      username: 'Testuser123456',
      email: 'harriis98@gmail.com',
      password: 'StrongPassword123!'
    },
    invalidEmailUser: {
      email: 'invalidemail'
    },
    existingEmailUser: {
      username: 'Testuser121212',
      email: 'harrii.boss@gmail.com',
      password: 'Testuser123!'
    }
  }
  